import os
import re
import json
from io import BytesIO

import requests
from flask import Flask, render_template, request, jsonify
from pypdf import PdfReader
from docx import Document

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB upload limit
OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://localhost:11434')
OLLAMA_MODEL = os.getenv('OLLAMA_MODEL', 'llama3.2')
ALLOWED_EXTENSIONS = {'.pdf', '.docx', '.txt'}


def extract_text(file_storage):
    filename = (file_storage.filename or '').lower()
    ext = os.path.splitext(filename)[1]
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError('Please upload a PDF, DOCX, or TXT file.')
    data = file_storage.read()
    if not data:
        raise ValueError('The uploaded file is empty.')
    if ext == '.pdf':
        reader = PdfReader(BytesIO(data))
        text = '\n'.join(page.extract_text() or '' for page in reader.pages)
    elif ext == '.docx':
        doc = Document(BytesIO(data))
        text = '\n'.join(p.text for p in doc.paragraphs)
        for table in doc.tables:
            text += '\n' + '\n'.join(' | '.join(cell.text for cell in row.cells) for row in table.rows)
    else:
        text = data.decode('utf-8', errors='replace')
    text = re.sub(r'\n{3,}', '\n\n', text).strip()
    if len(text) < 40:
        raise ValueError('I could not find enough readable text. Try a text-based PDF or DOCX file.')
    return text[:18000]


def ask_ollama(resume_text, job_description):
    prompt = f'''You are a helpful resume coach. Analyze the resume against the job description. Do not infer protected characteristics, age, gender, ethnicity, disability, or other sensitive traits. Be constructive and specific. The result is advice, not a hiring decision.

Return ONLY valid JSON with this exact shape:
{{
  "score": 0,
  "summary": "2-3 sentence summary",
  "strengths": ["strength 1", "strength 2", "strength 3"],
  "missing_keywords": ["keyword 1", "keyword 2"],
  "improvements": ["specific improvement 1", "specific improvement 2", "specific improvement 3"],
  "suggested_bullets": ["truthful bullet template 1", "truthful bullet template 2"],
  "interview_topics": ["topic 1", "topic 2"]
}}

Score is a rough 0-100 estimate of how closely the resume text matches the provided job description, not a prediction of hiring success. Do not invent experience or qualifications. Suggested bullets must use placeholders where facts are missing.

RESUME TEXT:
{resume_text}

JOB DESCRIPTION:
{job_description[:7000] if job_description else 'No job description supplied. Give general resume feedback and explain that keyword matching is limited.'}
'''
    response = requests.post(
        f'{OLLAMA_URL.rstrip("/")}/api/generate',
        json={'model': OLLAMA_MODEL, 'prompt': prompt, 'stream': False, 'format': 'json', 'options': {'temperature': 0.2}},
        timeout=180,
    )
    response.raise_for_status()
    body = response.json().get('response', '')
    try:
        result = json.loads(body)
    except json.JSONDecodeError:
        match = re.search(r'\{.*\}', body, re.S)
        if not match:
            raise ValueError('The AI returned an unreadable response. Please try again.')
        result = json.loads(match.group(0))
    result['score'] = max(0, min(100, int(result.get('score', 0))))
    for key in ('strengths', 'missing_keywords', 'improvements', 'suggested_bullets', 'interview_topics'):
        if not isinstance(result.get(key), list):
            result[key] = []
    result['summary'] = str(result.get('summary', 'Analysis complete.'))
    return result


@app.get('/')
def home():
    return render_template('index.html')


@app.get('/api/health')
def health():
    try:
        r = requests.get(f'{OLLAMA_URL.rstrip("/")}/api/tags', timeout=3)
        r.raise_for_status()
        models = [m.get('name', '') for m in r.json().get('models', [])]
        return jsonify({'ok': True, 'model': OLLAMA_MODEL, 'model_available': any(m == OLLAMA_MODEL or m.startswith(OLLAMA_MODEL + ':') for m in models), 'models': models})
    except requests.RequestException:
        return jsonify({'ok': False, 'model': OLLAMA_MODEL, 'message': 'Ollama is not reachable. Start Ollama and download the configured model.'}), 503


@app.post('/api/analyze')
def analyze():
    uploaded = request.files.get('resume')
    job_description = (request.form.get('job_description') or '').strip()
    if not uploaded or not uploaded.filename:
        return jsonify({'error': 'Choose a resume file first.'}), 400
    try:
        resume_text = extract_text(uploaded)
        result = ask_ollama(resume_text, job_description)
        return jsonify(result)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except requests.ConnectionError:
        return jsonify({'error': 'Cannot connect to Ollama. Make sure the Ollama app is running.'}), 503
    except requests.Timeout:
        return jsonify({'error': 'The AI took too long to respond. Try a smaller resume or a lighter model.'}), 504
    except requests.RequestException as exc:
        return jsonify({'error': f'Ollama request failed: {exc}'}), 502
    except Exception:
        app.logger.exception('Resume analysis failed')
        return jsonify({'error': 'Something went wrong while analyzing the resume. Check the backend terminal.'}), 500


@app.errorhandler(413)
def too_large(_error):
    return jsonify({'error': 'File is too large. Please keep it under 5 MB.'}), 413


if __name__ == '__main__':
    app.run(debug=True, port=int(os.getenv('PORT', '5000')))
