# ResumeLens AI — Hackathon Project

A full-stack AI resume analyzer prototype. The frontend is HTML/CSS/JavaScript, the backend is Python Flask, and the analysis runs through a locally hosted Ollama model. GitHub is used to version and collaborate on the code.

## Features
- Responsive resume-analysis website
- Upload PDF, DOCX, or TXT resumes (5 MB maximum)
- Optional job description for role-specific comparison
- AI-generated match estimate, strengths, keyword suggestions, improvements, bullet-point starters, and interview topics
- Download results as a TXT report
- Ollama health endpoint at `/api/health`
- Resume content is not written to a database or saved by this app

## Requirements
- Python 3.10+
- Git
- [Ollama](https://ollama.com/download)
- An Ollama model, for example `llama3.2`

## Run locally

### 1. Install and start Ollama
Install Ollama, then in a terminal run:

```bash
ollama pull llama3.2
ollama run llama3.2
```

Leave Ollama running. The first model download may take some time. You can use another installed model by setting `OLLAMA_MODEL`.

### 2. Set up the Python backend
Open a terminal in this project folder:

```bash
python -m venv .venv
```

Activate the environment:

**Windows PowerShell**
```powershell
.venv\Scripts\Activate.ps1
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install dependencies and start Flask:

```bash
pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000** in your browser. Keep the terminal and Ollama running while using the website.

Optional environment settings:

**Windows PowerShell**
```powershell
$env:OLLAMA_MODEL="llama3.2"
$env:OLLAMA_URL="http://localhost:11434"
python app.py
```

**macOS/Linux**
```bash
OLLAMA_MODEL=llama3.2 OLLAMA_URL=http://localhost:11434 python app.py
```

## Push the project to GitHub
Create a new empty repository on [GitHub](https://github.com), then run these commands inside this project folder (replace the example URL with your repository URL):

```bash
git init
git add .
git commit -m "Build ResumeLens AI resume analyzer"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Never commit private resumes, API keys, `.env` files, or real candidate data. `.gitignore` excludes common local files.

## Project structure

```text
ai-resume-analyzer/
├── app.py                 # Flask routes and Ollama integration
├── requirements.txt       # Python packages
├── templates/
│   └── index.html         # Website structure
├── static/
│   ├── styles.css         # Responsive design
│   └── app.js             # Upload, API call, results, report download
├── .gitignore
└── README.md
```

## How it works
1. The browser sends the selected file and optional job description to `POST /api/analyze`.
2. Flask extracts text from the resume and sends it to Ollama's local `/api/generate` endpoint.
3. Ollama returns structured JSON feedback.
4. The browser displays the results and can download a text report.

## Important notes for a hackathon demo
- This is a prototype, not a validated hiring or ATS scoring system. The score is a rough text-match estimate and should not be used to make hiring decisions.
- Use consented sample resumes for demos. Do not upload private personal documents to a public deployment without adding appropriate security, privacy notices, access controls, and retention policies.
- `debug=True` is for local development only. Turn debug mode off and use a production WSGI server before deployment.
- If you deploy the frontend/backend to a cloud host, a local Ollama process on your laptop will not automatically be available to the hosted backend. Host Ollama in an appropriately secured environment or configure a secured reachable model endpoint.
- Scanned/image-only PDFs may need OCR; this starter version extracts embedded PDF text only.
