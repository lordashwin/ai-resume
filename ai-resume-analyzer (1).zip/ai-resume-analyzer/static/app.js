const form = document.querySelector('#analyze-form');
const fileInput = document.querySelector('#resume-file');
const dropZone = document.querySelector('#drop-zone');
const fileTitle = document.querySelector('#file-title');
const fileSubtitle = document.querySelector('#file-subtitle');
const button = document.querySelector('#analyze-button');
const statusBox = document.querySelector('#status');
let latestReport = null;

function showFile(file) {
  if (!file) return;
  fileTitle.textContent = file.name;
  fileSubtitle.textContent = `${(file.size / 1024 / 1024).toFixed(2)} MB · Ready to analyze`;
}
fileInput.addEventListener('change', () => showFile(fileInput.files[0]));
['dragenter', 'dragover'].forEach(type => dropZone.addEventListener(type, e => { e.preventDefault(); dropZone.classList.add('dragover'); }));
['dragleave', 'drop'].forEach(type => dropZone.addEventListener(type, e => { e.preventDefault(); dropZone.classList.remove('dragover'); }));
dropZone.addEventListener('drop', e => {
  const file = e.dataTransfer.files[0];
  if (!file) return;
  const dt = new DataTransfer(); dt.items.add(file); fileInput.files = dt.files; showFile(file);
});

function listItems(id, items) {
  const ul = document.getElementById(id); ul.replaceChildren();
  (items || []).forEach(item => { const li = document.createElement('li'); li.textContent = item; ul.appendChild(li); });
  if (!items || items.length === 0) { const li = document.createElement('li'); li.textContent = 'No specific items returned.'; ul.appendChild(li); }
}
function renderReport(data) {
  latestReport = data;
  document.querySelector('#empty-state').classList.add('hidden');
  document.querySelector('#results').classList.remove('hidden');
  document.querySelector('#score-number').textContent = data.score;
  document.querySelector('#score-ring').style.background = `conic-gradient(#168579 ${data.score * 3.6}deg, #e0eee7 0deg)`;
  document.querySelector('#score-ring').style.borderColor = '#e0eee7';
  document.querySelector('#score-ring').style.borderTopColor = '#168579';
  document.querySelector('#summary').textContent = data.summary || '';
  document.querySelector('#score-title').textContent = data.score >= 80 ? 'Strong alignment' : data.score >= 60 ? 'Good foundation' : 'Room to strengthen';
  listItems('strengths', data.strengths);
  listItems('improvements', data.improvements);
  listItems('bullets', data.suggested_bullets);
  listItems('interview-topics', data.interview_topics);
  const keywords = document.querySelector('#keywords'); keywords.replaceChildren();
  (data.missing_keywords || []).forEach(word => { const tag = document.createElement('span'); tag.className = 'keyword'; tag.textContent = word; keywords.appendChild(tag); });
  if (!keywords.children.length) { const tag = document.createElement('span'); tag.className = 'keyword'; tag.textContent = 'No keywords suggested'; keywords.appendChild(tag); }
}
form.addEventListener('submit', async e => {
  e.preventDefault(); statusBox.textContent = '';
  const file = fileInput.files[0];
  if (!file) { statusBox.textContent = 'Please choose a resume file.'; return; }
  if (file.size > 5 * 1024 * 1024) { statusBox.textContent = 'Your file is larger than 5 MB.'; return; }
  button.disabled = true; button.querySelector('span').textContent = 'Analyzing with local AI…';
  statusBox.style.color = '#267568'; statusBox.textContent = 'Reading your resume and asking Ollama for feedback. This can take a minute on the first run.';
  try {
    const response = await fetch('/api/analyze', { method: 'POST', body: new FormData(form) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Analysis failed.');
    renderReport(data); statusBox.textContent = 'Analysis complete. Review the suggestions below.';
    document.querySelector('#results').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (err) {
    statusBox.style.color = '#a04d36'; statusBox.textContent = err.message || 'Could not connect to the backend.';
  } finally { button.disabled = false; button.querySelector('span').textContent = 'Analyze my resume'; }
});
document.querySelector('#download-report').addEventListener('click', () => {
  if (!latestReport) return;
  const lines = ['RESUMELENS AI — RESUME REVIEW', `Match score: ${latestReport.score}/100`, '', 'SUMMARY', latestReport.summary, '', 'STRENGTHS', ...(latestReport.strengths || []).map(x => `• ${x}`), '', 'KEYWORDS TO CONSIDER', ...(latestReport.missing_keywords || []).map(x => `• ${x}`), '', 'RECOMMENDED IMPROVEMENTS', ...(latestReport.improvements || []).map(x => `• ${x}`), '', 'BULLET POINT STARTERS', ...(latestReport.suggested_bullets || []).map(x => `• ${x}`), '', 'INTERVIEW TOPICS', ...(latestReport.interview_topics || []).map(x => `• ${x}`), '', 'Note: AI feedback can be imperfect. Verify suggestions and only include true information.'];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'resumelens-review.txt'; a.click(); URL.revokeObjectURL(url);
});
